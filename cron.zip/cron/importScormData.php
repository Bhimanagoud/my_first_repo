<?php
function open_connection_front_application(){
	//return open_connection('chc_website_fqmu_live', 'root', 'pass');
	return open_connection('fqmu_staging3_fqmu', 'fqmu_staging3', 'AfWakfaul7');
	//return open_connection('fqmu_staging2', 'fqmu_staging2', 'yosmybQuov5');
}

function open_connection_moodle_application(){
	//return open_connection('chc_website_fqmu_moodle_live', 'root', 'pass');
	return open_connection('fqmu_staging3_fqmu_moodle', 'fqmu_staging3', 'AfWakfaul7');
	//return open_connection('fqmu_staging2_fqmu', 'fqmu_staging2', 'yosmybQuov5');
}

function open_connection($database, $username, $password){
	$servername = "localhost";
	$conn = new mysqli($servername, $username, $password, $database);
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }
	return $conn;
}

function close_connection($conn){ mysqli_close($conn); }

function get_MoodleScormPackage($scormID){
	$conn = open_connection_front_application();
	$query = "SELECT id,scorm_package_id,moodle_scorm_id FROM moodle_scorm_package WHERE moodle_scorm_id = $scormID";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function get_MoodleUser($userID){
	$conn = open_connection_front_application();
	$query = "SELECT id, user_id,moodle_user_id FROM moodle_user WHERE moodle_user_id = $userID";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function get_ContentInstance($item_id,$item_type_id){
	$conn = open_connection_front_application();
	$query = "SELECT id,item_id,content_id,item_type_id FROM content_instance WHERE item_id = $item_id AND item_type_id = $item_type_id limit 1";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function get_Content($content_id){
	$conn = open_connection_front_application();
	$query = "SELECT id,vendor_id FROM content WHERE id = $content_id";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function get_MoodleScormSco($moodle_sco_id){
	$conn = open_connection_front_application();
	$query = "SELECT content_id FROM moodle_scorm_sco WHERE moodle_sco_id = $moodle_sco_id";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function get_UserContentLearning($user_id,$content_id){
	$conn = open_connection_front_application();
	$query = "SELECT current_score,max_score,lesson_status,total_time,start_date,completed_date,is_certified FROM user_content_learning WHERE user_id = $user_id AND content_id = $content_id";
	$result = $conn->query($query);
	close_connection($conn);
	if (isset($result->num_rows)) return $result->fetch_assoc();
}

function save_user_learning_information($userId,$contentId,$userLearning){
	try{
		$conn = open_connection_front_application();
		$setFields = "`update_date` = now()";
		foreach($userLearning as $key => $value){
			if(!is_null($value)){
				$setFields .= ", `$key`='$value'";
				$isFirstColumn = false;
			}
		}
		$query = "select Count(*) as count FROM user_content_learning where user_id = $userId and content_id = $contentId and status_id= 5";
		$result = $conn->query($query);
		
		if (isset($result->num_rows)){
			$result = $result->fetch_assoc();
			if($result['count'] == 0){
				//INSERT RECORD
				$query = "select max(id)+1 as id, max(sort_order)+1 as sort_order FROM user_content_learning";
				$result4maxvalues = $conn->query($query);
				$result4maxvalues = $result4maxvalues->fetch_assoc();
				print_r($result4maxvalues);
				$query = "INSERT INTO `user_content_learning`".
"(`id`,`user_id`,`content_id`,`content_rule_id`,`current_score`,`max_score`,`lesson_status`,`sort_order`,`status_id`,`creation_user_id`,`creation_date`,`is_certified`)".
"VALUES ('".$result4maxvalues['id']."',$userId,$contentId,(select content_rule_id from content where id = $contentId),0,0,'not attempted','".$result4maxvalues['sort_order']."',5,$userId,now(),0)";
				echo "<br/><br/>";
				print_r($query.";<br/><br/>");
				$result = $conn->query($query);
			}
			
			//UPDATE RECORD
			$query = "update user_content_learning set $setFields where user_id = $userId and content_id = $contentId and status_id= 5";
			echo "<br/><br/>";
			print_r($query.";<br/><br/>");
			$result = $conn->query($query);
		}
	} catch(Exception $ex){}
	finally{
		close_connection($conn);
	}
}

function runJob() {
	// ensure the script never times out
	set_time_limit(0);

	$objectivesRegEx = 'cmi.objectives.[0-9]+.id';

	// cache variables for use to reduce database overhead. Base objects have been initialised to prevent PHP warnings
	$moodleScormPackage = new stdClass();
	$moodleScormSco = new stdClass();
	$moodleUser = new stdClass();
	$contentInstance = new stdClass();
	$userLearningItems = array();
	$user = new stdClass();
	
	/* GET ALL UPDATES FROM MOODLE - mdl_scorm_scoes_track (PAST 30 mins) */
	$conn = open_connection_moodle_application();
	$query = "SELECT * FROM mdl_scorm_scoes_track
			WHERE ((
			  element = 'x.o.time'
			  
			  /* 2004 4th edition data models */
			  OR element = 'cmi.score.max'
			  OR element = 'cmi.score.raw'
			  OR element = 'cmi.completion_status'
			  OR element = 'cmi.total_time'
			  
			  /* 1.2 data models */
			  OR element = 'cmi.core.score.max'
			  OR element = 'cmi.core.score.raw'
			  OR element = 'cmi.core.lesson_status'
			  OR element = 'cmi.core.total_time'
			  
			  OR element REGEXP 'cmi.objectives.[0-9]+.id'
			)
			AND (timemodified > unix_timestamp(subdate(now(), INTERVAL 30 MINUTE))))
		  ORDER BY timemodified ASC, scoid ASC";
	$result = $conn->query($query);
	echo "<br/>QUERY:<br/>";
	print_r($query);
	
	echo "<br/><br/>RESULT:<br/>";
	print_r($result);echo "<br/><br/>";
	/*$arrayList = [];
	array_push($arrayList, Array ('id'=>'194653', 'userid' => '5', 'scormid' => '5843', 'scoid' => '20347', 'attempt' => '1', 'element' => 'cmi.objectives.0.id', 'value' => '01_discover_a', 'timemodified' => '1488536072'),
							Array ( 'id' => '194655', 'userid' => '5', 'scormid' => '5843', 'scoid' => '20347', 'attempt' => '1', 'element' => 'cmi.completion_status', 'value' => 'completed', 'timemodified' => '1488536072' ), 
							Array ( 'id' => '194685', 'userid' => '5', 'scormid' => '5843', 'scoid' => '20347', 'attempt' => '1', 'element' => 'cmi.total_time', 'value' => 'PT5M2.81S', 'timemodified' => '1488536072' ));
		
	for($i=0; $i<count($arrayList);$i++){
		$scoData = $arrayList[$i];*/
	while($scoData = $result->fetch_assoc()){
		print_r($scoData);echo "<br/><br/>";
		// easy variables
		$scoDataElement = $scoData['element']; $scoDataValue = $scoData['value']; $scoDataTimeModified = $scoData['timemodified'];
		
		// if the SCORM id does not match the already found SCORM package
		if (!property_exists($moodleScormPackage,"moodle_scorm_id") || $moodleScormPackage->moodle_scorm_id != $scoData['scormid']) {
			// find the MoodleScormPackage to use
			$moodleScormPackage = (object) get_MoodleScormPackage($scoData['scormid']);
		}
		
		echo "moodleScormPackage:<br/>";
		print_r($moodleScormPackage);
		echo "<br/><br/>";
		
		// if the SCORM user id does not match the already found Moodle user
		if (!property_exists($moodleUser,"moodle_user_id") || $moodleUser->moodle_user_id != $scoData['userid']){
			// find the MoodleUser to use
			$moodleUser = (object) get_MoodleUser($scoData['userid']);
		}
		echo "moodleUser:<br/>";
		print_r($moodleUser);
		echo "<br/><br/>";
		// if the moodle scorm package and the Moodle user exist
		if (!is_null($moodleScormPackage->id) && !is_null($moodleUser->id)) {
			
			// get the SCORM package to use
			$scormPackage = $moodleScormPackage;
			$scormPackage->id = $scormPackage->scorm_package_id;
			
			if (!property_exists($contentInstance,"item_id") || !($contentInstance->item_id == $scormPackage->id && $contentInstance->item_type_id == 13)) {
				// get the content instance from the database
				$contentInstance = (object) get_ContentInstance($scormPackage->id,13);
				
				// if the content instance has a valid Id
				if (!is_null($contentInstance->id)) {
					// get the content for the instance
					$content = (object) get_Content($contentInstance->content_id);
				}
			}
			echo "1st content:<br/>";
		print_r($content);
		echo "<br/><br/>";
			// if the content record gotten from the content instance is valid
			if (property_exists($content,"id")) {
				// if we have Edumine content, we need to update the correct sub piece of content
				//if ($content->vendor_id == 4 && preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {
				if (preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {

					// if the SCORM id does not match the already found SCORM package
					if (!property_exists($moodleScormSco,"moodle_sco_id") || $moodleScormSco->moodle_sco_id != $scoData['scoid']) {

						// find the MoodleScormPackage to use
						$moodleScormSco = (object) get_MoodleScormSco($scoData['scoid']);
						
						if (!is_null($moodleScormSco->content_id)) {
							$content = (object) get_Content($moodleScormSco->content_id);
						}
					}
				}
				echo "2nd content:<br/>";
		print_r($content);
		echo "<br/><br/>";
				if (property_exists($content,"id")) {
				
					$userLearning = isset($userLearningItems[$moodleUser->user_id][$content->id]) ? $userLearningItems[$moodleUser->user_id][$content->id] : null;
					
					if (is_null($userLearning)) {
						echo "Entered is_null(userLearning) <br/>";
						// create a new user learning object
						$userLearning = (object) get_UserContentLearning($moodleUser->user_id, $content->id);
						
						// special logic for Edumine courses
						//if (is_null($userLearning) && $content->vendor_id == 4 && preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {
						if (is_null($userLearning) && preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {
							
							// set the date time
							$dateTime = date('Y-m-d H:i:s', $scoDataTimeModified);

							// add as learning content on the user's wall and on learning pages
							//$user->addLearningContent($content);

							// add it to the users favourite by default
							//$user->addFavouriteContent($content);

							// log that the content was started
							//Logger::started($content, $content->instance()->study_duration, $dateTime);

							// create a new user learning object
							$userLearning = (object) get_UserContentLearning($moodleUser->user_id, $content->id);

							$userLearning->start_date = $dateTime;
						}
					}
					print_r($userLearning);
					if (!is_null($userLearning)) {
						echo "Entered !is_null(userLearning) <br/>";
						//error_log($scoDataElement);
						
						switch ($scoDataElement) {
							case 'x.start.time' :
								$userLearning->start_date = date('Y-m-d H:i:s', $scoDataValue);
								break;
							case 'cmi.core.score.raw':
							case 'cmi.score.raw' :
								$userLearning->current_score = $scoDataValue;
								break;
							case 'cmi.core.score.max':
							case 'cmi.score.max' :
								$userLearning->max_score = $scoDataValue;
								break;
							case 'cmi.core.total_time':
							case 'cmi.total_time' :
								$userLearning->total_time = $scoDataValue;
								break;
							case 'cmi.core.lesson_status':
							case 'cmi.completion_status' :
								$userLearning->lesson_status = $scoDataValue;

								break;
							default :
								// if we are updating Edumine content, and if we have detected that the user has completed an objective (this caters for when users move around inside the Edumine content)
								//if ($content->vendor_id == 4 && preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {
								if (preg_match('/' . $objectivesRegEx . '/', $scoDataElement)) {
									// flag lesson as completed
									$userLearning->lesson_status = 'completed';
								}
								break;
						}

						// if the lesson is completed and there is not currently a completed date available
						if (property_exists($userLearning,'lesson_status') && $userLearning->lesson_status == 'completed' && property_exists($userLearning,'completed_date') && is_null($userLearning->completed_date)) {

							// record completed date
							$userLearning->completed_date = date('Y-m-d H:i:s', $scoDataTimeModified);
							
							// remove certification
							//$userLearning->is_certified = 0;
						}

						// remember the learning item to save
						$userLearningItems[$moodleUser->user_id][$content->id] = $userLearning;
					}
				}
			}

		}
	}
	
	// unset the Scoes data to save on memory
	unset($scoesData);
	unset($moodleScormPackage);
	unset($moodleUser);
	unset($contentInstance);
	close_connection($conn);
	
	// go through each learning item
	foreach ($userLearningItems as $userId => $userLearningItem) {
		foreach ($userLearningItem as $contentId => $userLearning) {
			// save user learning information
			save_user_learning_information($userId,$contentId,$userLearning);
		}
	}
	
	echo "Job Successfully executed..!!";
}

runJob();